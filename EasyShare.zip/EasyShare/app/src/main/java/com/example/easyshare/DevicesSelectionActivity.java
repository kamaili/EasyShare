package com.example.easyshare;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;

public class DevicesSelectionActivity extends AppCompatActivity {
    private Object lock=new Object();
    private Intent previous_intent;
    private LinearLayout devices_layout;
    public static SendingAsyncTask senderTask;
    private FloatingActionButton reset_scan_btn;
    private  Context context;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // initialisation des attributs
        context=this;
        previous_intent=getIntent();
        setContentView(R.layout.activity_devices_selection);
        devices_layout=findViewById(R.id.devices_table);
        reset_scan_btn=findViewById(R.id.reset_scan);
        // démarrer une animation lors de recherche de appareils
        Drawable drawable = reset_scan_btn.getDrawable();
        if (drawable instanceof Animatable)
            ((Animatable) drawable).start();
    }

    @Override
    protected void onStart() {
        super.onStart();
        new Thread(new Runnable() {
            @Override
            public void run() {
                findDevices();
            }
        }).start();

        reset_scan_btn.setOnClickListener(view -> {
            recreate();
        });
    }


    public void addView(User usr){
        // uniquement le UI Thread peut créer des vues, pour ça on encapsule le code par "runOnUiThead"
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                RelativeLayout founded_device = (RelativeLayout) inflater.inflate(R.layout.device_info_area, null);
                ((TextView) founded_device.getChildAt(1)).setText(usr.getUsername());
                int resourceId = getResources().getIdentifier(usr.getAvatar(), "drawable",getPackageName());
                Drawable icon = AppCompatResources.getDrawable(getApplicationContext(), resourceId);
                ((ImageView) founded_device.getChildAt(0)).setImageDrawable(icon);
                /* On utilise la synchronisation pour empêcher
                les threads concurrents d'ajouter simultanément des vues au layout*/
                synchronized (lock){devices_layout.addView(founded_device);}
                // créer un Listener de click sur le bouton d'envoi pour cet appareil
                ((Button) founded_device.getChildAt(2)).setOnClickListener(view -> {
                    ArrayList<String> selected_files=(ArrayList<String>) previous_intent.getExtras().get("selected_files");

                    ((Button) view).setVisibility(View.INVISIBLE);
                    senderTask = new SendingAsyncTask(context,usr.getIpAddress(),selected_files);
                    senderTask.execute();



                });
            }


        });
    }

    public void findDevices(){


        String[] possibleAdresses = null;
        try{
            // liste des adresses possibles dans le plage d'adressage .
            possibleAdresses=NetworkHelper.getPossibleAdresses();
        }catch (Exception e){e.printStackTrace();}
        int requiredThreadNumber=(int)Math.ceil(possibleAdresses.length / 5)+1;
        // chaque Thread visite 5 vérifier 5 adresses pour limiter le temps du Scanning
        Thread[] finders=new Thread[requiredThreadNumber];
        int ArraySize=possibleAdresses.length;
        int actuel_thread_index=0;
                for (int i=0;i+5<ArraySize;i+=5) {
            (finders[actuel_thread_index++] = new Finder(
                    new String[]{possibleAdresses[i],
                            possibleAdresses[i + 1], possibleAdresses[i + 2],
                            possibleAdresses[i + 3], possibleAdresses[i + 4]}
            )).start();
        }

            String[] adresses_restantes;
        adresses_restantes = new String[ArraySize%5];
            for (int i=0; i<ArraySize%5; i++) {
                adresses_restantes[i] = possibleAdresses[(int) Math.ceil(ArraySize/5)+i];
            }
            (finders[actuel_thread_index] = new Finder(adresses_restantes)).start();

        for(int i=0;i<requiredThreadNumber;i++) {
            try {
                finders[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                reset_scan_btn.setImageResource(getResources().getIdentifier("reset_ic","drawable",getPackageName()));
            }
        });
    }
    private class Finder extends Thread{
        private String[] adresses;
        private Finder(String[] adresses){this.adresses=adresses;}
        @Override
        public void run(){

            for (String i:adresses) {
                Socket socket = null;
                SocketAddress socketAddress = new InetSocketAddress(i, 2024);
                socket = new Socket();
                try {

                    socket.connect(socketAddress, 3000);

                    InputStream is = socket.getInputStream();
                    ObjectInputStream objectInputStream = new ObjectInputStream(is);
                    User user = (User) objectInputStream.readObject();
                    addView(user);

                    objectInputStream.close();
                    is.close();
                } catch (Exception e) {
                   // e.printStackTrace();
                } finally {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

}