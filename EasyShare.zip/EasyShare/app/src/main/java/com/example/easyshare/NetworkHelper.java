package com.example.easyshare;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.net.*;
import java.util.ArrayList;
import java.util.Enumeration;

public final class NetworkHelper {


    public static String[] getPossibleAdresses() throws Exception {
        ArrayList<String> possibleAdresses=new ArrayList<>();
        String subnetMask = getSubnetMask();
        String ipAddress = getIpAddress();
        String[] subnetMaskParts = subnetMask.split("\\.");
        String[] ipAddressParts = ipAddress.split("\\.");

        int[] maskOctets = new int[4];
        int[] ipOctets = new int[4];

        for (int i = 0; i < 4; i++) {
            maskOctets[i] = Integer.parseInt(subnetMaskParts[i]);
            ipOctets[i] = Integer.parseInt(ipAddressParts[i]);
        }

        int[] networkAddress = new int[4];
        for (int i = 0; i < 4; i++) {
            networkAddress[i] = ipOctets[i] & maskOctets[i];
        }

        int[] broadcastAddress = new int[4];
        for (int i = 0; i < 4; i++) {
            broadcastAddress[i] = networkAddress[i] | (~maskOctets[i] & 0xFF);
        }

        for (int i = networkAddress[3] + 1; i < broadcastAddress[3]; i++) {
            String possibleAddress = networkAddress[0] + "." + networkAddress[1] + "." + networkAddress[2] + "." + i;
            possibleAdresses.add(possibleAddress);

        }

        return possibleAdresses.toArray(new String[possibleAdresses.size()]);
    }

    private static String getSubnetMask() throws SocketException {
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        while (interfaces.hasMoreElements()) {
            NetworkInterface currentInterface = interfaces.nextElement();
            if (currentInterface.isUp() && currentInterface.getName().startsWith("wlan")) {
                for (InterfaceAddress interfaceAddress : currentInterface.getInterfaceAddresses()) {
                    if (interfaceAddress.getAddress().getAddress().length == 4) {
                        return convertToSubnetMask(interfaceAddress.getNetworkPrefixLength());
                    }
                }
            }
        }
        return null;
    }

    private static String getIpAddress() throws SocketException {
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        while (interfaces.hasMoreElements()) {
            NetworkInterface currentInterface = interfaces.nextElement();
            if (currentInterface.isUp() && currentInterface.getName().startsWith("wlan")) {
                for (InterfaceAddress interfaceAddress : currentInterface.getInterfaceAddresses()) {
                    if (interfaceAddress.getAddress().getAddress().length == 4) {
                        return interfaceAddress.getAddress().getHostAddress();
                    }
                }
            }
        }
        return null;
    }

    private static String convertToSubnetMask(int prefixLength) {
        try {
            int value = 0xffffffff << (32 - prefixLength);
            byte[] bytes = new byte[]{
                    (byte) ((value >>> 24) & 0xff),
                    (byte) ((value >>> 16) & 0xff),
                    (byte) ((value >>> 8) & 0xff),
                    (byte) (value & 0xff)
            };
            InetAddress netAddr = InetAddress.getByAddress(bytes);
            return netAddr.getHostAddress();
        } catch (Exception e) {
            return null;
        }
    }

    private static String getWlanInterfaceName() throws SocketException {
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        while (interfaces.hasMoreElements()) {
            NetworkInterface currentInterface = interfaces.nextElement();
            if (currentInterface.isUp() && currentInterface.getName().startsWith("wlan")) {
                return currentInterface.getName();
            }
        }
        return null;
    }

    public static String getDeviceAddress() throws SocketException {

        String interfaceName=getWlanInterfaceName();
        NetworkInterface wlanInterface = NetworkInterface.getByName(interfaceName);
        if (wlanInterface != null) {
            for (InterfaceAddress address : wlanInterface.getInterfaceAddresses()) {
                if (address.getAddress().getAddress().length == 4) {
                    return address.getAddress().getHostAddress();
                }
            }
        }
        return null;
    }
    public static boolean isConnected(Context context){
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

// get network info for active network
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();

        return  activeNetwork != null && activeNetwork.isConnected() && activeNetwork.getType() == ConnectivityManager.TYPE_WIFI;
    }
}

