package com.example.easyshare;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyDataBaseHelper extends SQLiteOpenHelper {

    private Context context;
    public MyDataBaseHelper(@Nullable Context context) {
        super(context,"easyshare.db",null,1);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query="create table user (" +
                "name TEXT," +
                "avatar TEXT);";
        db.execSQL(query);
        query="create table history (" +
                "name TEXT," +
                "friendavatar TEXT," +
                "friendname TEXT," +
                "connexion_date DATE," +
                "avatar TEXT);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists contact.db");
        onCreate(db);
    }
    public boolean insert(String nom,String avat)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("name",nom);
        cv.put("avatar",avat);
        try {
            if(db.insert("user",null,cv)<0) throw new Exception();
        }catch (Exception e){
            return false;
        }
        return true;
    }
    public boolean isProfileExists(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("select * from user",null);
        return res.getCount() != 0;
    }
    public User getUserInfos(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("select * from user",null);
        assert (this.isProfileExists());
        res.moveToFirst();
        return new User(res.getString(0),res.getString(1),null,0);
    }
    public boolean update(String newUsername,String newAvatar)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("name",newUsername);
        cv.put("avatar",newAvatar);
        try {
            if(db.update("user",cv,null,null)<0) throw new Exception();

        }catch (Exception e){
            return false;
        }
        return true;
    }

}
