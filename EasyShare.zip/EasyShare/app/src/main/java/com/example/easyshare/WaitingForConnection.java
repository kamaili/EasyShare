package com.example.easyshare;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class WaitingForConnection extends AsyncTask<Void, Void, Void> {

    private final Context context;
    private int port;
    private ServerSocket serverSocket;

    public WaitingForConnection(Context context,int port){
        this.context=context;
        this.port = port;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        try {
            serverSocket=new ServerSocket(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected Void doInBackground(Void... voids) {
            try {
                assert NetworkHelper.isConnected(context);
                Socket socket;
                while (!isCancelled() && !serverSocket.isClosed()){

                    socket=serverSocket.accept();
                    // send user infos
                    OutputStream os = socket.getOutputStream();
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(os);
                    User user = MainActivity.dataBaseHelper.getUserInfos();
                    user.setIpAddress(NetworkHelper.getDeviceAddress());
                    objectOutputStream.writeObject(user);
                    objectOutputStream.flush();
                    objectOutputStream.close();
                    os.close();
                    socket.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        return  null;
    }
    public void closeServer(){
        try {
            serverSocket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



}
