package com.example.easyshare;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;


public class AccountFragment extends Fragment {

    private TableLayout avatar_table;
    private ImageButton[] avatars;
    private View selectedAvatar;
    private TextView username_area;

    public AccountFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

this.container=container;
        return inflater.inflate(R.layout.account_fragment, container, false);
    }
private View container;
    @Override
    public void onStart() {
        super.onStart();
        username_area=getActivity().findViewById(R.id.actuel_username);
        User actual_user=MainActivity.dataBaseHelper.getUserInfos();
        username_area.setText(actual_user.getUsername());
        getActivity().findViewById(R.id.update_btn).setOnClickListener(view -> {
            if(MainActivity.dataBaseHelper.update(username_area.getText().toString(),getResources().getResourceEntryName(selectedAvatar.getId())))
                Toast.makeText(getActivity(), "profile updated", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(getActivity(), "fail to update", Toast.LENGTH_SHORT).show();

        });
        int actual_avatar_id=getResources().getIdentifier(actual_user.getAvatar(), "id", getActivity().getPackageName());
        updateAvatar(getActivity().findViewById(actual_avatar_id));
        avatar_table=getActivity().findViewById(R.id.tableLayout2);
        avatars=new ImageButton[9];
        int index=0;
        for(int i=0;i<3;i++){
            TableRow actual_row=(TableRow) avatar_table.getChildAt(i);
            avatars[index++]= (ImageButton) actual_row.getChildAt(0);
            avatars[index++]= (ImageButton) actual_row.getChildAt(1);
            avatars[index++]= (ImageButton) actual_row.getChildAt(2);
        }
        for(int i=0;i<9;i++)
            avatars[i].setOnClickListener(view -> updateAvatar(view));
    }
    public void updateAvatar(View view) {
        if(selectedAvatar!=null)
            selectedAvatar.setBackgroundColor(Color.WHITE);
        selectedAvatar=view;
        selectedAvatar.setBackgroundColor(Color.parseColor("#FF3DDB83"));
    }

}