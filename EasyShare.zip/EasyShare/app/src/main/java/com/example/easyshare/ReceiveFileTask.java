package com.example.easyshare;



import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.widget.ImageView;
import android.widget.Toast;

import com.skyfishjy.library.RippleBackground;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Map;

public class ReceiveFileTask extends AsyncTask<Void, Integer, Void> {
    private final Context context;
    private int port;
    ArrayList<Map.Entry<String,Long>> files_with_sizes;
    private User user;
    private ProgressDialog dialog;
    private ServerSocket serverSocket;
    private boolean isSucceeded;
    private ProgressDialog progressDialog;
    private Map.Entry<String, Integer> progressValue;


    public ReceiveFileTask(Context context, int port)
    {
        this.port = port;
        this.context=context;
    }

    protected void onPreExecute() {
        super.onPreExecute();
        try {
            serverSocket=new ServerSocket(2023);
        } catch (IOException e) {
            e.printStackTrace();
        }
        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle(context.getResources().getIdentifier("receiving...","string",context.getPackageName()));
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setMessage("");
        progressDialog.setProgress(0);
        progressDialog.setMax(100);
    }

    @Override
    protected Void doInBackground(Void... voids) {
            try {
                if(! isCancelled() && ! serverSocket.isClosed()){
                    Receiver rec= new Receiver(serverSocket,2023);
                    rec.startReceiving();
                    isSucceeded=true;
                }
            } catch (Exception e) {
                isSucceeded=false;e.printStackTrace();
            }
        return null;
    }

    @Override
    protected void onPostExecute(Void unused) {
        super.onPostExecute(unused);
        progressDialog.dismiss();
        closeServer();
        if(isSucceeded) {
            closeServer();
            Intent intent=new Intent(context,MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            Toast.makeText(MainActivity.context, "operation Succeeded", Toast.LENGTH_SHORT).show();
        }else{
            closeServer();
            Toast.makeText(context, "operation failed", Toast.LENGTH_SHORT).show();
            ReceivingActivity.main_layout.setBackgroundColor(Color.RED);
            RippleBackground rbg= (RippleBackground) ReceivingActivity.main_layout.getChildAt(0);
            rbg.stopRippleAnimation();
            int imageViewId = context.getResources().getIdentifier("centered_icon", "id", context.getPackageName());
            ImageView centerd_icon= ReceivingActivity.main_layout.findViewById(imageViewId);
            centerd_icon.setImageDrawable(context.getDrawable(context.getResources().getIdentifier("reset_ic","drawable",context.getPackageName())));
            centerd_icon.setOnClickListener(view -> {
                Intent intent=new Intent(context,ReceivingActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(intent);
            });
        }
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        if (!progressDialog.isShowing())
            progressDialog.show();
        // Update the progress dialog message
        progressDialog.setMessage(progressValue.getKey());
        progressDialog.setProgress(progressValue.getValue());
    }
    public void updateProgress(Map.Entry<String,Integer> progress) {
        // This method can be called from outside the AsyncTask to update the progress
        progressValue = progress;
        publishProgress(0);
    }
    public void closeServer(){
        try {
            serverSocket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}