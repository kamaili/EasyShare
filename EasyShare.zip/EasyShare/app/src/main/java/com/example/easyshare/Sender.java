package com.example.easyshare;

import android.os.Environment;

import java.io.*;
import java.net.*;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Map;

public class Sender {
    private final String SERVER_ADDRESS;
    private int SERVER_PORT;
    private final ArrayList<String> files_to_send;
    private Socket socket;

    public Sender(ArrayList<String> files_to_send, String SERVER_ADDRESS, int SERVER_PORT) throws IOException {
        this.files_to_send=files_to_send;
        this.SERVER_PORT=SERVER_PORT;
        this.SERVER_ADDRESS=SERVER_ADDRESS;
    }

    public void startSending()throws Exception{
        socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
        OutputStream in = socket.getOutputStream();
        DataOutputStream dis=new DataOutputStream(in);
        int fileNumber=files_to_send.size();
        dis.writeInt(fileNumber);
        socket.close();
        for(int i=0;i<fileNumber;i++){
            String actual_file_path=files_to_send.get(i);
            // toujours afficher le fichier en cours d'envoi
            sendFile(actual_file_path);
        }

    }
    public void sendFile(String path) throws NotCompletelyReceived {

        try {
            File file=new File(Environment.getExternalStorageDirectory().getAbsolutePath()+path);
            socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            OutputStream out = socket.getOutputStream();
            DataOutputStream dos=new DataOutputStream(out);
            long fileSize=file.length();
            // send file name
            dos.writeUTF(file.getName());
            // send file size
            dos.writeLong(fileSize);
            dos.flush();
            // send file
            FileInputStream fis = new FileInputStream(file);
            BufferedInputStream bis=new BufferedInputStream(fis);
            byte[] buffer = new byte[4096];
            int bytesRead;
            float progress=0;
            while ((bytesRead = bis.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
                progress += ((float) bytesRead / fileSize) * 100;
                DevicesSelectionActivity.senderTask.updateProgress(new AbstractMap.SimpleEntry<>(file.getName(),(int)progress));
            }
            bis.close();
            fis.close();
            out.flush();
        } catch (IOException e) {
            throw new NotCompletelyReceived();
        }finally {
            /* l'instruction socket.close() doit toujours mise dans le bloc finally pour
            qu'elle etre executée dans tous les cas */
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

