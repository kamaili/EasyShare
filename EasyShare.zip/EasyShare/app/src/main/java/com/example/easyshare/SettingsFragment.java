package com.example.easyshare;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Locale;


public class SettingsFragment extends Fragment {


    public SettingsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.settings_fragment, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        Spinner languageSpinner=getActivity().findViewById(R.id.spinner);
        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                // Set the app's language based on the selected language
                if (position==1) {
                    changeAndApplyChanges("en");
                } else if (position==2) {
                    changeAndApplyChanges("fr");
                } else if (position==3) {
                    changeAndApplyChanges("ar");
                }
            }
            private void changeAndApplyChanges(String lang){
                // Build the dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage(getResources().getIdentifier("restart_for_changes","string", getActivity().getPackageName()));
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Locale locale = new Locale(lang);
                        Locale.setDefault(locale);
                        Resources resources = getResources();
                        Configuration config = resources.getConfiguration();
                        config.setLocale(locale);
                        resources.updateConfiguration(config, resources.getDisplayMetrics());
                        // je rencontre des bug quand j'appèle recreate()
                        Intent intent=new Intent(getActivity(),MainActivity.class);
                        startActivity(intent);
                        getActivity().finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        languageSpinner.setSelection(0);
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        TextView share_app=getActivity().findViewById(R.id.share_app);
        share_app.setOnClickListener(view -> {
            extractApk();
            sendWithBluetooth();

        });
        }

    private void sendWithBluetooth() {
        // Get a file object for the file to be shared
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+"/EasyShare/base.apk");


// Get the URI of the file using a FileProvider
        Uri fileUri = FileProvider.getUriForFile(getActivity(), "com.example.easyshare.fileprovider", file);

// Create an intent to share the file via Bluetooth
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_STREAM, fileUri);
        intent.setPackage("com.android.bluetooth");

// Grant read permission to the receiving app
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

// Verify that there is an activity to handle the intent
        PackageManager packageManager = getActivity().getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(intent, 0);
        if (activities.size() > 0) {
            // Start the activity to share the file via Bluetooth
            startActivity(intent);
        }


    }

    private void extractApk(){
            // Get the package name of the current app
            String packageName = getActivity().getPackageName();

// Create a package manager instance
            PackageManager packageManager = getActivity().getPackageManager();

// Get the APK file path of the current app
            String apkFilePath = null;
            try {
                ApplicationInfo applicationInfo = packageManager.getApplicationInfo(packageName, 0);
                apkFilePath = applicationInfo.sourceDir;
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }

// Copy the APK file to external storage
            if (apkFilePath != null) {
                File apkFile = new File(apkFilePath);
                File easyShareDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EasyShare");
                File apkCopy = new File(easyShareDir, apkFile.getName());

                try (InputStream in = new FileInputStream(apkFile);
                     OutputStream out = new FileOutputStream(apkCopy)) {
                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = in.read(buffer)) > 0) {
                        out.write(buffer, 0, length);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
}