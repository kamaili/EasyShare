package com.example.easyshare;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;


public class SignUpFragment extends Fragment {

    private View selectedAvatar=null;
    private EditText user_name_area;
    private TableLayout avatar_table;

    public SignUpFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.sign_up_fragment, container, false);
    }



    @Override
    public void onStart() {
        super.onStart();
        user_name_area=getActivity().findViewById(R.id.user_name);
        avatar_table=getActivity().findViewById(R.id.tableLayout);
        ImageButton[] avatars=new ImageButton[9];
        int index=0;
        for(int i=0;i<3;i++){
            TableRow actual_row=(TableRow) avatar_table.getChildAt(i);
            avatars[index++]= (ImageButton) actual_row.getChildAt(0);
            avatars[index++]= (ImageButton) actual_row.getChildAt(1);
            avatars[index++]= (ImageButton) actual_row.getChildAt(2);
        }
        for(int i=0;i<9;i++)
            avatars[i].setOnClickListener(view -> updateAvatar(view));
        Button btn=(Button) getActivity().findViewById(R.id.submit_btn);
        btn.setOnClickListener(view -> {
            try {
                if(user_name_area.getText().length()==0) throw new Exception("Enter your username");
                if(selectedAvatar== null) throw new Exception("Select an avatar");
                String user_name=user_name_area.getText().toString();
                //the avatar name is the same as the ID of the ImageView
                String avatar=getResources().getResourceEntryName(selectedAvatar.getId());
                if(!MainActivity.dataBaseHelper.insert(user_name,avatar)) throw new Exception("Creation failed");


                Toast.makeText(getActivity(), "profile created", Toast.LENGTH_SHORT).show();
                getActivity().recreate();
            }catch (Exception e){
                Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void updateAvatar(View view) {
        if(selectedAvatar!=null)
            selectedAvatar.setBackgroundColor(Color.WHITE);
        selectedAvatar=  view;
        selectedAvatar.setBackgroundColor(Color.parseColor("#FF3DDB83"));
    }
}
