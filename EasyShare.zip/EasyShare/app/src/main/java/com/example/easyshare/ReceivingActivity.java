package com.example.easyshare;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.icu.text.CaseMap;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;

import com.skyfishjy.library.RippleBackground;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutionException;

public class ReceivingActivity extends AppCompatActivity {

    private RippleBackground rippleBackground;

    public static ReceiveFileTask rft;
    //make this AsyncTask public static to can cancel it from the Receiver AsyncTask when start receiving files
    public static WaitingForConnection wfc;
    public static RelativeLayout main_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_receiving);
        main_layout=findViewById(R.id.receive_main_layout);
        rippleBackground=findViewById(R.id.rippleBackground);
        rippleBackground.startRippleAnimation();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            wfc=new WaitingForConnection(this,2024);
            rft=new ReceiveFileTask(this,2023);
            rft.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            wfc.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        }else{
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                int requestCode = 123;
                requestPermissions(permissions, requestCode);
        }
    }


    @Override
    // annuler les taches de WaintingForConnection et ReceivingFileTask
    public void onBackPressed() {
        super.onBackPressed();
        // les server sockets doivent etres fermées avant de stopper un AsyncTask en java
        rft.closeServer();
        wfc.closeServer();

        rft.cancel(true);
        wfc.cancel(true);
    }
}