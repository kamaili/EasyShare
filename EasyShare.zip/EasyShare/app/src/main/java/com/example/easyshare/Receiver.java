package com.example.easyshare;

import android.os.Environment;

import java.io.*;
import java.net.*;
import java.util.AbstractMap;

public class Receiver {

    private  int PORT = 2023;
    private ServerSocket serverSocket;

    public Receiver(ServerSocket serverSocket, int PORT) throws IOException {this.PORT=PORT;
        this.serverSocket=serverSocket;
    }
    public void startReceiving()throws Exception{
        Socket socket = serverSocket.accept();
        // close waiting task when start receiving files
        ReceivingActivity.wfc.closeServer();
        ReceivingActivity.wfc.cancel(true);
        InputStream in = socket.getInputStream();
        DataInputStream dis=new DataInputStream(in);
        int fileNumber=dis.readInt();
        socket.close();
        for(int i=0;i<fileNumber;i++)
            receiveFile();
        serverSocket.close();
    }
    public void  receiveFile()throws Exception {


                Socket socket = serverSocket.accept();
                InputStream in = socket.getInputStream();
                DataInputStream dis=new DataInputStream(in);
                String filename=dis.readUTF();
                long fileSize=dis.readLong();
                File received_file = null;
                File easyShareDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EasyShare");
                if (!easyShareDir.exists()) {
                    easyShareDir.mkdirs();
                }
                received_file=new File(easyShareDir,filename);
                received_file.createNewFile();




                FileOutputStream fos = new FileOutputStream(received_file);
                BufferedOutputStream bos=new BufferedOutputStream(fos);
                byte[] buffer = new byte[4096];
                int bytesRead;
                float progress=0;
                while ((bytesRead = in.read(buffer)) != -1) {
                    bos.write(buffer, 0, bytesRead);
                    progress += ((float) bytesRead / fileSize) * 100;
                    ReceivingActivity.rft.updateProgress(new AbstractMap.SimpleEntry<>(filename,(int)progress));
                }
                bos.flush();
                bos.close();
                fos.close();
                socket.close();
                if (fileSize != received_file.length()) throw new NotCompletelyReceived();

    }
}

