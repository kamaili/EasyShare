package com.example.easyshare;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class User implements Serializable {
    private String username;
    private String avatar;
    private String ipAddress;
    private int FilesToSendCount;
    public User(String username,String avatar,String ipAddress,int FilesToSendCount){
        this.avatar=avatar;
        this.username=username;
        this.ipAddress=ipAddress;
        FilesToSendCount=FilesToSendCount;
    }

    public int getFilesToSendCount() {
        return FilesToSendCount;
    }

    public void setFilesToSendCount(int filesToSendCount) {
        FilesToSendCount = filesToSendCount;
    }

    public String getAvatar() {
        return avatar;
    }

    public String getUsername() {
        return username;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    @NonNull
    @Override
    public String toString() {
        return username+" "+avatar+" "+ipAddress;
    }
}
