package com.example.easyshare;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Map;

public class SendingAsyncTask extends AsyncTask<String, Integer, Void> {

    private final int port = 2023;
    private final Context context;
    private String host;
    private ArrayList<String> files_to_send;
    private ProgressDialog progressDialog;
    private boolean isSucceeded = true;
    private Map.Entry<String, Integer> progressValue;

    public SendingAsyncTask(Context context, String host, ArrayList<String> files_to_send) {
        this.host = host;
        this.files_to_send = files_to_send;
        this.context=context;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        // instruction à exectuer avant l'execution de la méthode doInBackground
        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle(context.getResources().getIdentifier("sending...","string",context.getPackageName()));
        progressDialog.setMessage("");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setProgress(0);
        progressDialog.setMax(100);
        progressDialog.show();
    }

    @Override
    protected Void doInBackground(String... strings) {
        try {
            // lancer l'envoi des fichiers
            (new Sender(files_to_send,host,port)).startSending();
        } catch (Exception e) {
            isSucceeded=false;e.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onPostExecute(Void result) {
        super.onPostExecute(result);
        // instruction à exectuer après l'execution de la méthode doInBackground
        // Dismiss the progress dialog
        progressDialog.dismiss();
        Intent intent=new Intent(context,MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

        Toast.makeText(MainActivity.context, (isSucceeded)?"operation succeeded":"operation failed", Toast.LENGTH_SHORT).show();

    }
    @Override
    /* cette méthode va etre appelée implicitement lorsqu'on appele la méthode publishProgress de la
    classe AsyncTask pour mettre à jour la valeur de progression du ProgressDialog */
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        // Update the progress dialog message
        progressDialog.setMessage(progressValue.getKey());
        progressDialog.setProgress(progressValue.getValue());
    }
    public void updateProgress(Map.Entry<String,Integer> progress) {
        // This method can be called from outside the AsyncTask to update the progress
            progressValue = progress;
            publishProgress(0);
    }
}