package com.example.easyshare;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    public static Context context;
    public static MyDataBaseHelper dataBaseHelper;
    private HomeFragment home_fr;
    private SettingsFragment settings_fr;
    private AccountFragment account_fr;
    private SignUpFragment signup_fr;
    private BottomNavigationView navigation_view;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialisation des attributs
        context=this;
        dataBaseHelper=new MyDataBaseHelper(getApplicationContext());
        home_fr=new HomeFragment();
        settings_fr=new SettingsFragment();
        account_fr=new AccountFragment();
        signup_fr=new SignUpFragment();
        navigation_view=findViewById(R.id.nav_button);

    }

    @Override
    protected void onStart() {
        super.onStart();
        // vérifier l'existance d'un profile enregistré dans la BD
        if (dataBaseHelper.isProfileExists())
        {
            // afficher le menu principale
            replace_fragment(R.id.container,home_fr);
            navigation_view.setSelectedItemId(R.id.home);
        }
        else
        {
            // afficher la zone de création de profile
            replace_fragment(R.id.container,signup_fr);
            navigation_view.setSelectedItemId(R.id.account);
        }
        navigation_view.setOnItemSelectedListener(item -> {
            // blocker les buttons de navigation s'il n'y a pas de profile
            if (!dataBaseHelper.isProfileExists())
                Toast.makeText(this, "create profile first", Toast.LENGTH_SHORT).show();
            else
                // naviguer vers les zones de paramètres, gestion de profile et menu principal
                switch (item.getItemId()){
                    case R.id.home:
                        replace_fragment(R.id.container,home_fr);
                        return true;
                    case R.id.account:
                        replace_fragment(R.id.container,account_fr);
                        return true;
                    case R.id.settings:
                        replace_fragment(R.id.container,settings_fr);
                        return true;
                }
            return false;
        });
    }


    public void replace_fragment(int id, Fragment frag){
        getSupportFragmentManager().beginTransaction().replace(id,frag).commit();
    }

}