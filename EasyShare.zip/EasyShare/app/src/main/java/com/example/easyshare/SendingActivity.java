package com.example.easyshare;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

public class SendingActivity extends AppCompatActivity {
    private final int PICK_FILE_REQUEST_CODE = 123;

    private FloatingActionButton add_files_btn;
    private LinearLayout files_table;
    private ArrayList<String> List_Files;
    private int rowsCount;
    private TextView NoFileSelected;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sender);
        // initialisation des attributs
        add_files_btn=findViewById(R.id.add_file_btn);
        files_table=findViewById(R.id.files_table);
        List_Files=new ArrayList<>();
        rowsCount=0;
        // afficher le texte "No File Selected" par défaut
        showEmptyView(true);
        add_files_btn.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                // Créez un intent pour ouvrir l'explorateur de fichiers
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("*/*"); // set the type of file to select
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                //set the starting directory to the Downloads folder
                intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:/Download"));
                startActivityForResult(Intent.createChooser(intent, "Select File"), PICK_FILE_REQUEST_CODE);

            }else{
                String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                int requestCode = 123;
                requestPermissions(permissions, requestCode);
            }

        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Button search_devices_btn=findViewById(R.id.search_devices_btn);
        search_devices_btn.setOnClickListener(view -> {
            if (List_Files.size()==0)
                Toast.makeText(this, "No files to send !", Toast.LENGTH_SHORT).show();
            else if (!NetworkHelper.isConnected(this))
                Toast.makeText(this, "you must connect to a network !", Toast.LENGTH_SHORT).show();
            else{
                Intent devicesSelection=new Intent(this,DevicesSelectionActivity.class);
                //passer la liste des fichier à envoyer
                devicesSelection.putExtra("selected_files",List_Files);
                startActivity(devicesSelection);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_FILE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            // Récupérez l'URI du fichier sélectionné
            String Path=getPathFromUri(data.getData());
            if (List_Files.contains(Path))
                Toast.makeText(this, "file already selected", Toast.LENGTH_SHORT).show();
            else{
                List_Files.add(Path); // ajouter le chemin du fichier sélectionné dans la liste

                showEmptyView(false); // éliminer le texte "No File Selected" s'il existe
            }
        }
    }

    private String getPathFromUri(Uri data) {
        String path=data.getPath();
        return "/"+path.substring(path.lastIndexOf(':')+1);


    }

    @Override
    protected void onResume() {
        super.onResume();

        // when new file is selected
        if(rowsCount < List_Files.size()){
            RelativeLayout row= (RelativeLayout) getLayoutInflater().inflate(R.layout.file_area,null);
            /* mettre le hashcode de chemin du nouveau fichier comme ID de vue associe pour
            l'identifie après facilement lors de suppression du vue */
            row.setId(List_Files.get(rowsCount).hashCode());
            TextView file_name_area= (TextView) row.getChildAt(0);
            String file_path=List_Files.get(rowsCount);
            String file_name=file_path.substring(file_path.lastIndexOf('/')+1);
            file_name_area.setText(file_name);
            files_table.addView(row);
            rowsCount++;
            ((ImageButton) row.getChildAt(1)).setOnClickListener(view -> {
                // supprimer l'élément de la liste qui a comme ID le hashcode de vue à supprimer
                List_Files.removeIf(item -> item.hashCode() == row.getId());
                files_table.removeView(row);
                rowsCount--;
                if (rowsCount==0) showEmptyView(true);
            });
        }
    }

    private void showEmptyView(Boolean b){
        if(b){
            NoFileSelected=new TextView(this);
            NoFileSelected.setText(getResources().getIdentifier("list_empty","string",getPackageName()));
            NoFileSelected.setTextSize(20);
            files_table.addView(NoFileSelected);
        }
        else{
            files_table.removeView(NoFileSelected);
            files_table.setPadding(30,30,30,30);
        }
    }



}