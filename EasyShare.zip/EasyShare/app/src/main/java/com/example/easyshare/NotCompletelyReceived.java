package com.example.easyshare;

public class NotCompletelyReceived extends Exception {
    public NotCompletelyReceived(){super();}
}
